
import { useEffect, useState } from 'react';
import './App.css';
import axios, { toFormData } from 'axios';

function App() {


  let [data, setData] = useState([])
    // console.log(data)


  let myForm = (e) => {

    e.preventDefault()

    var myValue = {
      name: e.target.name.value,
      mobile: e.target.mobile.value,
      email: e.target.email.value,
      password: e.target.password.value,
      id:editData.id
    }
    // console.log(myValue)
    axios.post('https://raipradeep.in/form-api/saveUser.php', toFormData(myValue))
      .then(function (response) {
        console.log(response);
      })
      .catch(function (error) {
        console.log(error);
      });
      
      HandeData()
      e.target.reset()

  }
 
  // show Data
  let HandeData = () => {
    axios.get("https://raipradeep.in/form-api/viewUser.php")
      .then(function (response) {
        setData(response.data.dataList);
      })

  }
  useEffect(()=>{
    HandeData()
  },[])


  // DeleteRow
  let DeleteRow=(myId)=>{
    // console.log(myId)
    axios.get('https://raipradeep.in/form-api/deleteUser.php?', {
      params: {
        enid: myId
      }
    })
    .then(function (response) {
      // console.log(response);
    })
    HandeData()

  }

  // searchValue
  let searchValue=(e)=>{
      // console.log(e.target.value)
      var ssValue=e.target.value
      // console.log(ssValue)
      axios.get('https://raipradeep.in/form-api/viewUser.php?', {
        params: {
          sname: ssValue
        }
      })
      .then(function (response) {
        // console.log(response.data.dataList);
        setData(response.data.dataList)
      })
      
  }




  // update
  let [editData,seteditData]=useState({
    name:"",
    email:"",
    mobile:"",
    password:"",
    id:""
  })
  console.log(editData)
  
  let editRow=(MyeditId)=>{
    axios.get('https://raipradeep.in/form-api/viewUser.php?', {
      params: {
        editId: MyeditId
      }
    })
    .then(function (response) {
      // seteditData(response.data.dataList);
      seteditData({
        name:response.data.dataList.en_name,
        email:response.data.dataList.en_email,
        mobile:response.data.dataList.en_contact,
        password:response.data.dataList.en_password,
        id:response.data.dataList.en_id
      })
      
    })
  
  }
  // console.log(editData)

  let handeInputs=(e)=>{
    let data={...editData}
    data[e.target.name]=e.target.value
    seteditData(data)
 
  }

 

  return (
    <div className="App ">
      <div className='container bg-secondary mt-3 p-2 w-50'>
        <form onSubmit={myForm}>
          <div className="mb-3">
            <label for="exampleInputEmail1" className="form-label">Name</label>
            <input type="text" placeholder='Name' className="form-control" value={editData.name} onChange={handeInputs} name='name' />

          </div>
          <div className="mb-3">
            <label for="exampleInputEmail1" className="form-label">Mobile</label>
            <input type="Number" placeholder='Mobile' className="form-control" value={editData.mobile} onChange={handeInputs} name='mobile' />

          </div>
          <div className="mb-3">
            <label for="exampleInputEmail1" className="form-label">Email </label>
            <input type="email" placeholder='email' className="form-control"  value={editData.email} onChange={handeInputs} name='email' />

          </div>
          <div className="mb-3">
            <label for="exampleInputPassword1" className="form-label">Password</label>
            <input type="text" placeholder='Password' className="form-control"  value={editData.password} onChange={handeInputs} name='password' />
          </div>

          <button type="submit" className="btn btn-primary">Submit</button>
        </form>


        
        {/* table */}


      </div>
      <div className='my-5 '>
        <input type='text' placeholder='Search By Name' onChange={searchValue} className='w-50 '/>
      </div>

      <div className='container'>
        <table className="table" >
          <thead >
            <tr >
              <th scope="col" className='bg-secondary'>Sr.</th>
              <th scope="col" className='bg-secondary'>Id</th>
              <th scope="col" className='bg-secondary'>Name</th>
              <th scope="col" className='bg-secondary'>Email</th>
              <th scope="col" className='bg-secondary'>Contact</th>
              <th scope="col" className='bg-secondary'>Password</th>
              <th scope="col" className='bg-secondary'></th>
              <th scope="col" className='bg-secondary'></th>
            </tr>
          </thead>
          <tbody>

            {data.length>=1
            ?
            data.map((v,i)=>{
              return(
                <tr key={i}>
                <th scope="row">{i+1}</th>
                <td>{v.en_id}</td>
                <td>{v.en_name}</td>
                <td>{v.en_email}</td>
                <td>{v.en_contact}</td>
                <td>{v.en_password}</td>
                <td> <button className="btn btn-primary" onClick={()=>editRow(v.en_id)}>Edit</button> </td>
                <td><button className="btn btn-primary" onClick={()=>DeleteRow(v.en_id)}>Delete</button> </td>
              </tr>
              )
            })
            :
            "No data Found"
          }
           

          </tbody>
        </table>
      </div>
    </div>
  );
}

export default App;
